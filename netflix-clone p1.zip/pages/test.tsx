const MyPage = () => {
  return <h1>Hello New Page</h1>;
};

export default MyPage;
